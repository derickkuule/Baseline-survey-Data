STATA and SPSS file all sections Follow-up survey
